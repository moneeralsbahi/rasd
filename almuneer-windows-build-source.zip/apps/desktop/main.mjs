import { app, BrowserWindow, shell, autoUpdater } from 'electron';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isHttps = (value) => /^https:\/\//i.test(value || '');

function configureUpdater() {
  const feed = process.env.ALMUNEER_UPDATE_FEED_URL?.trim();
  if (!app.isPackaged || !isHttps(feed)) return;
  autoUpdater.setFeedURL({ url: feed });
  autoUpdater.on('error', (error) => console.error('[updater]', error));
  autoUpdater.checkForUpdates().catch((error) => console.error('[updater]', error));
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 960,
    minHeight: 640,
    show: false,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      devTools: process.env.NODE_ENV !== 'production',
    },
  });

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (isHttps(url)) void shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file:')) {
      event.preventDefault();
      if (isHttps(url)) void shell.openExternal(url);
    }
  });
  win.once('ready-to-show', () => win.show());
  void win.loadFile(path.resolve(__dirname, '../web/dist/index.html'));
}

app.whenReady().then(() => {
  createWindow();
  configureUpdater();
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
