# Desktop Wrapper

Windows أولًا باستخدام Electron/NSIS، مع نفس البنية قابلة لـ macOS (`dmg`) وLinux (`AppImage`). تم تعطيل `nodeIntegration` وتفعيل `contextIsolation` و`sandbox` ومنع navigation إلى عناوين غير محلية؛ الروابط الخارجية HTTPS فقط تفتح في المتصفح.

## التحديث
توجد بنية Auto-update اختيارية عبر `ALMUNEER_UPDATE_FEED_URL`. لا تعمل إلا عندما يكون التطبيق packaged وعنوان التحديث HTTPS. هذه بنية جاهزية فقط؛ خادم التحديث والتوقيع الرقمي لم يُختبرا في البيئة الحالية.

## NSIS
الإعداد الحالي ينشئ اختصار سطح المكتب وقائمة Start وUninstaller ويسمح باختيار مجلد التثبيت. اسم artifact محدد بصورة ثابتة قابلة للأرشفة.

يوجد Workflow في `.github/workflows/release-build.yml` لتوليد Windows artifact على `windows-latest`. لم يُنفذ من بيئة الجلسة الحالية، لذلك Windows installer ما يزال BLOCKED محليًا.
