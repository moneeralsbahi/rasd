export type AdminLoginResponse={accessToken:string;refreshToken:string;expiresIn:number;user:{id:string;displayName:string}};
export type StudentRow={id:string;full_name:string;seat_number:string;grade?:string|null;class_section?:string|null;school?:string|null;governorate?:string|null;phone?:string|null;guardian_phone?:string|null;notes?:string|null;status:'active'|'archived';created_at:string;updated_at:string};
export type Page<T>={items:T[];page:number;pageSize:number;total:number};

export type QuestionRow={id:string;legacy_ref?:string|null;question_type:string;stem:string;explanation?:string|null;difficulty?:number|null;metadata:Record<string,unknown>;status:'active'|'archived'|'deleted';option_count:number;taxonomy_ids:string[];created_at:string;updated_at:string};
export type QuestionOptionInput={key:string;content:string;isCorrect:boolean;sortOrder?:number};
export type QuestionInput={legacyRef?:string|null;questionType:string;stem:string;explanation?:string|null;difficulty?:number|null;metadata?:Record<string,unknown>;taxonomyIds?:string[];tags?:string[];options?:QuestionOptionInput[]};
export type ImportJob={id:string;kind:string;status:'queued'|'running'|'completed'|'failed'|'cancelled';source_name:string;total_rows:number;processed_rows:number;error_rows:number;last_batch_no:number;report?:Record<string,unknown>;created_at:string;updated_at?:string;completed_at?:string|null};
export type DeviceRow={id:string;name:string;browser?:string|null;os?:string|null;first_ip?:string|null;last_ip?:string|null;first_login_at:string;last_login_at:string;status:'active'|'blocked';active_sessions:number};

export type ExamAdminRow={id:string;name:string;description?:string|null;duration_minutes:number;attempts_allowed:number;pass_percentage:number;starts_at?:string|null;ends_at?:string|null;status:'draft'|'published'|'closed'|'archived';policy:Record<string,unknown>;access_mode?:'all'|'allowlist';public_link_enabled?:boolean;question_count:number;created_at:string;updated_at:string};
export type ExamInput={name:string;description?:string|null;gradeId?:string|null;subjectId?:string|null;durationMinutes:number;attemptsAllowed?:number;passPercentage?:number;startsAt?:string|null;endsAt?:string|null;policy?:{randomizeQuestions?:boolean;randomizeChoices?:boolean;oneQuestionPerPage?:boolean;allowBackNavigation?:boolean;autoSubmit?:boolean;showScoreAfterSubmit?:boolean;showCorrectAnswersAfterSubmit?:boolean;showExplanationsAfterSubmit?:boolean};questions:Array<{questionId:string;points?:number;sortOrder?:number}>};
export type StudentLoginResponse={accessToken:string;refreshToken:string;expiresIn:number;student:{id:string;fullName:string;seatNumber:string};deviceId:string;sessionId:string};
export type StudentExamRow={id:string;name:string;description?:string|null;duration_minutes:number;attempts_allowed:number;pass_percentage:number;starts_at?:string|null;ends_at?:string|null;policy:Record<string,unknown>;subject_id?:string|null;subject_name?:string|null;question_count:number;attempts_used:number};
export type StudentAttemptStart={attemptId:string;attemptNo:number;serverDeadlineAt:string;exam:{id:string;name:string;description?:string|null;gradeId?:string|null;subjectId?:string|null;durationMinutes:number;policy:Record<string,unknown>;questions:Array<{questionId:string;points:number;questionType:string;stem:string;difficulty?:number|null;metadata?:Record<string,unknown>;options?:Array<{key:string;content:string;sortOrder?:number}>;attachments?:Array<{id:string;filename:string;mimeType:string;sizeBytes:number;sha256:string}>}>}};
export type StudentResult={id?:string;attemptId:string;score?:number;maxScore?:number;percentage?:number;correctCount?:number;wrongCount?:number;skippedCount?:number;passed?:boolean;status?:string;details?:unknown[];explanations?:unknown[]};

export type StudentAnalyticsDashboard={summary:{resultCount:number;examCount:number;trainingCount:number;completedTraining:number;cumulativeAverage:number;bestPercentage:number;recentAverage:number;improvement:number;rank:number|null;rankedStudents:number;correct:number;wrong:number;skipped:number;accuracy:number;totalAnswerTimeMs:number;averageAnswerTimeMs:number};recent:Array<{percentage:number;created_at:string}>};
export type ErrorBankRow={question_id:string;stem:string;question_type:string;difficulty?:number|null;mistake_count:number;correct_count:number;last_mistake_at?:string|null;last_correct_at?:string|null;weakness_score:number};
export type TrainingQuestion={questionId:string;questionType:string;stem:string;difficulty?:number|null;metadata?:Record<string,unknown>;options?:Array<{key:string;content:string;sortOrder?:number}>};
export type TrainingSessionStart={sessionId:string;mode:'random'|'errors'|'weakness'|'taxonomy'|'unsolved'|'adaptive';total:number;questions:TrainingQuestion[]};
export type TaxonomyNode={id:string;parent_id?:string|null;kind:string;name:string;code?:string|null;sort_order:number;status:'active'|'archived'};
export type AdminDashboard={kpis:{students:{active:number;total:number};questions:{active:number;total:number};exams:{published:number;total:number};results:{total:number;average:number;last30:number};subscriptions:{active:number;expired:number;expiring_soon:number};attempts:{total:number;in_progress:number;submitted:number}};subjects:Array<{name:string;questions:number}>;difficulty:Array<{difficulty:number|null;questions:number}>;performanceTrend:Array<{day:string;average:number;attempts:number}>};
export type ResultReportRow={id:string;student_id:string;full_name:string;seat_number:string;exam_id:string;exam_name:string;score:number;max_score:number;percentage:number;correct_count:number;wrong_count:number;skipped_count:number;duration_ms:number;created_at:string};



export type AdminUserRow={id:string;display_name:string;username?:string|null;email?:string|null;status:'active'|'suspended'|'archived';created_at:string;updated_at:string;roles:Array<{id:string;code:string;name:string}>};
export type AdminRoleRow={id:string;code:string;name:string;is_system:boolean;permissions:string[]};
export type TenantSettings={tenant_id:string;product_name:string;organization_name?:string|null;logo_url?:string|null;theme_mode:'system'|'light'|'dark';accent_color:string;font_scale:number;ui_scale:number;high_contrast:boolean;reduced_motion:boolean;ranking_enabled:boolean;academic_year?:string|null;academic_term?:string|null;footer_text?:string|null;developer_name?:string|null;updated_at:string};
export class ApiClient {
  constructor(private readonly baseUrl: string, private readonly getToken?: () => string | undefined) {}

  async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const headers = new Headers(init.headers);
    headers.set('accept', 'application/json');
    if (init.body && !headers.has('content-type')) headers.set('content-type', 'application/json');
    const token = this.getToken?.();
    if (token) headers.set('authorization', `Bearer ${token}`);
    const response = await fetch(`${this.baseUrl}${path}`, {...init, headers});
    const payload = response.status===204 ? null : await response.json().catch(() => null) as T | {message?: string} | null;
    if (!response.ok) throw new Error((payload as {message?: string} | null)?.message ?? `HTTP ${response.status}`);
    return payload as T;
  }

  adminLogin(identifier:string,password:string){ return this.request<AdminLoginResponse>('/api/v1/auth/admin/login',{method:'POST',body:JSON.stringify({identifier,password})}); }
  adminRefresh(refreshToken:string){ return this.request<Omit<AdminLoginResponse,'user'>>('/api/v1/auth/admin/refresh',{method:'POST',body:JSON.stringify({refreshToken})}); }
  adminLogout(){ return this.request<void>('/api/v1/auth/admin/logout',{method:'POST'}); }
  listStudents(params:{page?:number;pageSize?:number;search?:string;status?:'active'|'archived'}={}){
    const q=new URLSearchParams(); Object.entries(params).forEach(([k,v])=>{if(v!==undefined) q.set(k,String(v));});
    return this.request<Page<StudentRow>>(`/api/v1/admin/students${q.size?`?${q}`:''}`);
  }
  createStudent(input:{fullName:string;seatNumber:string;grade?:string|null;classSection?:string|null;school?:string|null;governorate?:string|null;phone?:string|null;guardianPhone?:string|null;notes?:string|null}){
    return this.request<StudentRow>('/api/v1/admin/students',{method:'POST',body:JSON.stringify(input)});
  }
  archiveStudent(studentId:string){ return this.request<void>(`/api/v1/admin/students/${encodeURIComponent(studentId)}/archive`,{method:'POST'}); }
  listSubscriptions(input:{page?:number;pageSize?:number;status?:string;search?:string}={}){const q=new URLSearchParams();Object.entries(input).forEach(([k,v])=>{if(v!==undefined&&v!=='')q.set(k,String(v))});return this.request<any>(`/api/v1/admin/subscriptions?${q}`);}
  extendSubscription(id:string,days:number){return this.request<any>(`/api/v1/admin/subscriptions/${encodeURIComponent(id)}/extend`,{method:'POST',body:JSON.stringify({days})});}
  revokeSubscription(id:string){return this.request<void>(`/api/v1/admin/subscriptions/${encodeURIComponent(id)}/revoke`,{method:'POST'});}
  bulkIssueSubscriptions(studentIds:string[],durationDays:number){return this.request<any>('/api/v1/admin/subscriptions/bulk-issue',{method:'POST',body:JSON.stringify({studentIds,durationDays})});}
  exportSubscriptionsCsv(){return this.request<{filename:string;mimeType:string;contentBase64:string;count:number}>('/api/v1/admin/subscriptions/export.csv');}
  listTeachers(input:{page?:number;pageSize?:number;search?:string;status?:string}={}){const q=new URLSearchParams();Object.entries(input).forEach(([k,v])=>{if(v!==undefined&&v!=='')q.set(k,String(v))});return this.request<any>(`/api/v1/admin/teachers?${q}`);}
  createTeacher(input:any){return this.request<any>('/api/v1/admin/teachers',{method:'POST',body:JSON.stringify(input)});}
  updateTeacher(id:string,input:any){return this.request<any>(`/api/v1/admin/teachers/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify(input)});}
  exportTeachersCsv(){return this.request<{filename:string;mimeType:string;contentBase64:string;count:number}>('/api/v1/admin/teachers/export.csv');}
  issueSubscription(input:{studentId:string;durationDays:number;startsAt?:string}){
    return this.request<{subscriptionId:string;code:string;codeHint:string;startsAt:string;endsAt:string;status:'active'}>('/api/v1/admin/subscriptions',{method:'POST',body:JSON.stringify(input)});
  }
  suspendSubscription(subscriptionId:string){ return this.request<void>(`/api/v1/admin/subscriptions/${encodeURIComponent(subscriptionId)}/suspend`,{method:'POST'}); }
  listStudentDevices(studentId:string){ return this.request<{items:DeviceRow[]}>(`/api/v1/admin/students/${encodeURIComponent(studentId)}/devices`); }
  revokeSession(sessionId:string){ return this.request<void>(`/api/v1/admin/sessions/${encodeURIComponent(sessionId)}/revoke`,{method:'POST'}); }
  revokeAllStudentSessions(studentId:string){ return this.request<{revoked:number}>(`/api/v1/admin/students/${encodeURIComponent(studentId)}/sessions/revoke-all`,{method:'POST'}); }
  blockDevice(deviceId:string){ return this.request<void>(`/api/v1/admin/devices/${encodeURIComponent(deviceId)}/block`,{method:'POST'}); }
  unblockDevice(deviceId:string){ return this.request<void>(`/api/v1/admin/devices/${encodeURIComponent(deviceId)}/unblock`,{method:'POST'}); }
  listQuestions(params:{page?:number;pageSize?:number;search?:string;status?:'active'|'archived'|'deleted';questionType?:string;difficulty?:number;taxonomyId?:string;gradeId?:string;subjectId?:string}={}){
    const q=new URLSearchParams(); Object.entries(params).forEach(([k,v])=>{if(v!==undefined) q.set(k,String(v));});
    return this.request<Page<QuestionRow>>(`/api/v1/admin/questions${q.size?`?${q}`:''}`);
  }
  getQuestion(questionId:string){ return this.request<QuestionRow & {options:Array<{id:string;option_key:string;content:string;is_correct:boolean;sort_order:number}>;taxonomy:Array<{id:string;kind:string;name:string;code?:string|null}>}>(`/api/v1/admin/questions/${encodeURIComponent(questionId)}`); }
  setQuestionTags(id:string,tags:string[]){return this.request<any>(`/api/v1/admin/questions/${encodeURIComponent(id)}/tags`,{method:'PUT',body:JSON.stringify({tags})});}
  bulkQuestionStatus(questionIds:string[],status:'active'|'archived'){return this.request<any>('/api/v1/admin/questions/bulk-status',{method:'POST',body:JSON.stringify({questionIds,status})});}
  createQuestion(input:QuestionInput){ return this.request<QuestionRow>('/api/v1/admin/questions',{method:'POST',body:JSON.stringify(input)}); }
  archiveQuestion(questionId:string){ return this.request<void>(`/api/v1/admin/questions/${encodeURIComponent(questionId)}/archive`,{method:'POST'}); }
  deleteQuestion(questionId:string){ return this.request<{id:string;status:'deleted'}>(`/api/v1/admin/questions/${encodeURIComponent(questionId)}`,{method:'DELETE'}); }
  restoreDeletedQuestion(questionId:string){ return this.request<{id:string;status:'active'}>(`/api/v1/admin/questions/${encodeURIComponent(questionId)}/restore`,{method:'POST'}); }
  createQuestionImport(input:{sourceName:string;kind?:'questions_json_batches'|'questions_csv'|'questions_xlsx';totalRows?:number}){ return this.request<ImportJob>('/api/v1/admin/question-imports',{method:'POST',body:JSON.stringify(input)}); }
  getQuestionImport(jobId:string){ return this.request<ImportJob>(`/api/v1/admin/question-imports/${encodeURIComponent(jobId)}`); }
  appendQuestionImportBatch(jobId:string,batchNo:number,rows:unknown[],mode:'skip'|'upsert'='skip'){ return this.request<{jobId:string;batchNo:number;mode:string;received:number;inserted:number;updated:number;duplicates:number;invalid:number}>(`/api/v1/admin/question-imports/${encodeURIComponent(jobId)}/batches`,{method:'POST',body:JSON.stringify({batchNo,mode,rows})}); }
  completeQuestionImport(jobId:string){ return this.request<ImportJob>(`/api/v1/admin/question-imports/${encodeURIComponent(jobId)}/complete`,{method:'POST'}); }

  listExamsAdmin(){ return this.request<{items:ExamAdminRow[]}>('/api/v1/admin/exams'); }
  createExam(input:ExamInput){ return this.request<{id:string;status:'draft'}>('/api/v1/admin/exams',{method:'POST',body:JSON.stringify(input)}); }
  publishExam(examId:string){ return this.request<void>(`/api/v1/admin/exams/${encodeURIComponent(examId)}/publish`,{method:'POST'}); }
  buildExam(input:{name:string;description?:string|null;count:number;durationMinutes:number;attemptsAllowed?:number;passPercentage?:number;questionType?:string;difficulty?:number;taxonomyId?:string;randomizeQuestions?:boolean;randomizeChoices?:boolean}){ return this.request<{id:string;status:'draft'}>('/api/v1/admin/exams/build',{method:'POST',body:JSON.stringify(input)}); }

  previewAdminExam(examId:string){return this.request<any>(`/api/v1/admin/exams/${encodeURIComponent(examId)}/preview`);}
  printAdminExam(examId:string){return this.request<{filename:string;mimeType:string;contentBase64:string}>(`/api/v1/admin/exams/${encodeURIComponent(examId)}/print`);}
  setExamAccess(examId:string,accessMode:'all'|'allowlist',studentIds:string[]){return this.request<{examId:string;accessMode:string;studentCount:number}>(`/api/v1/admin/exams/${encodeURIComponent(examId)}/access`,{method:'PUT',body:JSON.stringify({accessMode,studentIds})});}
  createExamPublicLink(examId:string,enabled=true){return this.request<{examId:string;enabled:boolean;token?:string}>(`/api/v1/admin/exams/${encodeURIComponent(examId)}/public-link`,{method:'POST',body:JSON.stringify({enabled})});}
  getAdminHeatmap(){return this.request<{students:any[];exams:any[];cells:any[]}>('/api/v1/admin/analytics/heatmap');}
  listGradebook(page=1,pageSize=50){return this.request<Page<any>>(`/api/v1/admin/gradebook?page=${page}&pageSize=${pageSize}`);}
  rebuildGradebook(){return this.request<{rebuilt:true;students:number;rebuiltAt:string}>('/api/v1/admin/gradebook/rebuild',{method:'POST'});}
  studentLogin(input:{seatNumber:string;subscriptionCode:string;device:{fingerprint:string;name:string;browser?:string;os?:string}}){ return this.request<StudentLoginResponse>('/api/v1/auth/student/login',{method:'POST',body:JSON.stringify(input)}); }
  studentRefresh(refreshToken:string){ return this.request<{accessToken:string;refreshToken:string;expiresIn:number}>('/api/v1/auth/student/refresh',{method:'POST',body:JSON.stringify({refreshToken})}); }
  studentLogout(){ return this.request<void>('/api/v1/auth/student/logout',{method:'POST'}); }
  listStudentExams(){ return this.request<{items:StudentExamRow[]}>('/api/v1/student/exams'); }
  startStudentExam(examId:string){ return this.request<StudentAttemptStart>(`/api/v1/student/exams/${encodeURIComponent(examId)}/start`,{method:'POST'}); }
  saveStudentAnswer(attemptId:string,input:{questionId:string;answer:unknown;timeSpentMs?:number}){ return this.request<{saved:true}>(`/api/v1/student/attempts/${encodeURIComponent(attemptId)}/answer`,{method:'PUT',body:JSON.stringify(input)}); }
  submitStudentAttempt(attemptId:string){ return this.request<StudentResult>(`/api/v1/student/attempts/${encodeURIComponent(attemptId)}/submit`,{method:'POST'}); }
  listStudentResults(){ return this.request<{items:Array<{id:string;attempt_id:string;exam_id:string;exam_name:string;score:number;max_score:number;percentage:number;correct_count:number;wrong_count:number;skipped_count:number;duration_ms:number;created_at:string}>;summary:{count:number;average:number}}>('/api/v1/student/results'); }
  getStudentResultDetail(resultId:string){return this.request<any>(`/api/v1/student/results/${encodeURIComponent(resultId)}`);}
  getPublicExam(examId:string,token:string){return this.request<any>(`/api/v1/public/exams/${encodeURIComponent(examId)}/${encodeURIComponent(token)}`);}
  redeemExamLink(examId:string,token:string){return this.request<{granted:true;examId:string}>(`/api/v1/student/exams/${encodeURIComponent(examId)}/redeem-link`,{method:'POST',body:JSON.stringify({token})});}

  getActiveStudentAttempt(){ return this.request<{attempt:null|{attempt_id:string;exam_id:string;name:string;server_deadline_at:string;current_question:number;started_at:string}}>('/api/v1/student/attempts/active'); }
  resumeStudentAttempt(attemptId:string){ return this.request<StudentAttemptStart & {currentQuestion:number;answers:Record<string,unknown>}>(`/api/v1/student/attempts/${encodeURIComponent(attemptId)}/resume`); }
  saveStudentCurrentQuestion(attemptId:string,index:number){ return this.request<{saved:true}>(`/api/v1/student/attempts/${encodeURIComponent(attemptId)}/current-question`,{method:'PUT',body:JSON.stringify({index})}); }
  downloadStudentQuestionFile(attemptId:string,questionId:string,fileId:string){return this.request<{id:string;filename:string;mimeType:string;sizeBytes:number;sha256:string;contentBase64:string}>(`/api/v1/student/attempts/${encodeURIComponent(attemptId)}/questions/${encodeURIComponent(questionId)}/files/${encodeURIComponent(fileId)}`);}
  startTraining(input:{mode:'random'|'errors'|'weakness'|'taxonomy'|'unsolved'|'adaptive';count:number;taxonomyId?:string;taxonomyIds?:string[];questionType?:string;difficulty?:number;sourceId?:string}){ return this.request<TrainingSessionStart>('/api/v1/student/training',{method:'POST',body:JSON.stringify(input)}); }
  resumeTraining(sessionId:string){ return this.request<any>(`/api/v1/student/training/${encodeURIComponent(sessionId)}`); }
  answerTraining(sessionId:string,input:{questionId:string;answer:unknown}){ return this.request<{isCorrect:boolean|null;explanation?:string|null;correctAnswer?:unknown;progress:{answered:number;total:number};completed:boolean}>(`/api/v1/student/training/${encodeURIComponent(sessionId)}/answer`,{method:'POST',body:JSON.stringify(input)}); }
  getStudentAnalytics(){ return this.request<StudentAnalyticsDashboard>('/api/v1/student/analytics/dashboard'); }
  getStudentRanking(scope:'global'|'institution'|'school'|'grade'|'class'|'subject'|'exam'='global',extra:{subjectId?:string;examId?:string}={}){const q=new URLSearchParams({scope});if(extra.subjectId)q.set('subjectId',extra.subjectId);if(extra.examId)q.set('examId',extra.examId);return this.request<{enabled:boolean;scope:string;rank:number|null;total:number;average:number|null}>(`/api/v1/student/analytics/ranking?${q}`);}
  listStoredFiles(input:{ownerType?:string;ownerId?:string}={}){const q=new URLSearchParams();Object.entries(input).forEach(([k,v])=>{if(v)q.set(k,String(v))});return this.request<{items:any[]}>(`/api/v1/admin/files${q.size?`?${q}`:''}`);}
  uploadStoredFile(input:{ownerType:'question'|'tenant'|'report'|'backup'|'other';ownerId?:string|null;originalName:string;mimeType:string;contentBase64:string;metadata?:Record<string,unknown>}){return this.request<any>('/api/v1/admin/files',{method:'POST',body:JSON.stringify(input)});}
  downloadStoredFile(fileId:string){return this.request<{filename:string;mimeType:string;sizeBytes:number;sha256:string;contentBase64:string}>(`/api/v1/admin/files/${encodeURIComponent(fileId)}/download`);}
  deleteStoredFile(fileId:string){return this.request<{deleted:true}>(`/api/v1/admin/files/${encodeURIComponent(fileId)}`,{method:'DELETE'});}
  pullSync(afterSequence=0,limit=500){return this.request<{events:any[];nextSequence:number;hasMore:boolean}>(`/api/v1/admin/sync/pull?afterSequence=${afterSequence}&limit=${limit}`);}
  saveSyncCheckpoint(input:{clientId:string;clientKind:'web'|'pwa'|'android'|'desktop'|'local_node';lastServerSequence:number;lastClientSequence:number;metadata?:Record<string,unknown>}){return this.request<any>('/api/v1/admin/sync/checkpoint',{method:'POST',body:JSON.stringify(input)});}
  pushSync(input:{clientId:string;events:Array<{clientEventId:string;clientSequence:number;entityType:string;entityId?:string|null;operation:'upsert'|'archive'|'delete'|'revoke';baseServerSequence?:number;payload?:Record<string,unknown>}>}){return this.request<{accepted:number;duplicates:number;conflicts:number}>('/api/v1/admin/sync/push',{method:'POST',body:JSON.stringify(input)});}
  listSyncConflicts(){return this.request<{items:any[]}>('/api/v1/admin/sync/conflicts');}
  resolveSyncConflict(conflictId:string,resolution:'local_wins'|'remote_wins'|'merged',mergedPayload?:Record<string,unknown>){return this.request<any>(`/api/v1/admin/sync/conflicts/${encodeURIComponent(conflictId)}/resolve`,{method:'POST',body:JSON.stringify({resolution,mergedPayload})});}
  getStudentErrorBank(page=1,pageSize=25){ return this.request<Page<ErrorBankRow>>(`/api/v1/student/error-bank?page=${page}&pageSize=${pageSize}`); }
  getStudentStrengthsWeaknesses(){ return this.request<{weaknesses:any[];strengths:any[]}>('/api/v1/student/analytics/strengths-weaknesses'); }
  verifyStudentResultIntegrity(resultId:string){ return this.request<{resultId:string;verified:boolean;status:'verified'|'mismatch'|'legacy_unhashed';algorithm:string|null;version:number|null;hash?:string}>(`/api/v1/student/results/${encodeURIComponent(resultId)}/integrity`); }


  updateQuestion(questionId:string,input:QuestionInput){ return this.request<QuestionRow>(`/api/v1/admin/questions/${encodeURIComponent(questionId)}`,{method:'PUT',body:JSON.stringify(input)}); }
  duplicateQuestion(questionId:string){ return this.request<QuestionRow>(`/api/v1/admin/questions/${encodeURIComponent(questionId)}/duplicate`,{method:'POST'}); }
  moveQuestion(questionId:string,taxonomyIds:string[]){ return this.request<void>(`/api/v1/admin/questions/${encodeURIComponent(questionId)}/taxonomy`,{method:'PUT',body:JSON.stringify({taxonomyIds})}); }
  mergeQuestions(targetQuestionId:string,sourceQuestionIds:string[]){ return this.request<{targetQuestionId:string;merged:number}>(`/api/v1/admin/questions/${encodeURIComponent(targetQuestionId)}/merge`,{method:'POST',body:JSON.stringify({sourceQuestionIds})}); }
  getQuestionQuality(questionId:string){ return this.request<{questionId:string;score:number;issues:Array<{code:string;severity:'warning'|'error';message:string}>}>(`/api/v1/admin/questions/${encodeURIComponent(questionId)}/quality`); }
  setQuestionFavorite(questionId:string,favorite:boolean){ return this.request<{favorite:boolean}>(`/api/v1/admin/questions/${encodeURIComponent(questionId)}/favorite`,{method:'PUT',body:JSON.stringify({favorite})}); }
  listTaxonomy(){ return this.request<{items:TaxonomyNode[]}>('/api/v1/admin/taxonomy'); }
  createTaxonomy(input:{parentId?:string|null;kind:'grade'|'subject'|'branch'|'unit'|'lesson'|'topic'|'source'|'teacher'|'committee'|'academic_year';name:string;code?:string|null;sortOrder?:number}){ return this.request<TaxonomyNode>('/api/v1/admin/taxonomy',{method:'POST',body:JSON.stringify(input)}); }
  updateTaxonomy(id:string,input:{parentId?:string|null;name?:string;code?:string|null;sortOrder?:number;status?:'active'|'archived'}){ return this.request<TaxonomyNode>(`/api/v1/admin/taxonomy/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify(input)}); }
  getReport(type:'student'|'class'|'grade'|'subject'|'exam'|'subscription'|'teacher'|'performance'|'question_difficulty'|'effectiveness'|'error_analysis',filters:Record<string,string>={}){const q=new URLSearchParams(filters);return this.request<any>(`/api/v1/admin/reports/${type}?${q}`);}
  getAdminDashboard(){ return this.request<AdminDashboard>('/api/v1/admin/analytics/dashboard'); }
  getResultsReport(params:{page?:number;pageSize?:number;studentId?:string;examId?:string}={}){const q=new URLSearchParams();Object.entries(params).forEach(([k,v])=>{if(v!==undefined)q.set(k,String(v));});return this.request<Page<ResultReportRow>>(`/api/v1/admin/reports/results${q.size?`?${q}`:''}`);}
  createEncryptedBackup(password:string){ return this.request<{backupId:string;filename:string;contentBase64:string;checksum:string;sizeBytes:number}>('/api/v1/admin/backups',{method:'POST',body:JSON.stringify({password})}); }
  verifyEncryptedBackup(password:string,contentBase64:string){ return this.request<{valid:true;checksum:string;payloadSummary:{format:string;version:number;createdAt:string;tables:number}}>('/api/v1/admin/backups/verify',{method:'POST',body:JSON.stringify({password,contentBase64})}); }


  listAdminUsers(page=1,pageSize=50){ return this.request<Page<AdminUserRow>>(`/api/v1/admin/users?page=${page}&pageSize=${pageSize}`); }
  createAdminUser(input:{displayName:string;username?:string|null;email?:string|null;password:string;roleIds?:string[]}){ return this.request<{id:string}>('/api/v1/admin/users',{method:'POST',body:JSON.stringify(input)}); }
  updateAdminUser(userId:string,input:Partial<{displayName:string;username:string|null;email:string|null;password:string;status:'active'|'suspended'|'archived';roleIds:string[]}>){ return this.request<{id:string}>(`/api/v1/admin/users/${encodeURIComponent(userId)}`,{method:'PATCH',body:JSON.stringify(input)}); }
  listAdminRoles(){ return this.request<{items:AdminRoleRow[]}>('/api/v1/admin/roles'); }
  listPermissions(){ return this.request<{items:Array<{id:string;code:string;description?:string|null}>}>('/api/v1/admin/permissions'); }
  createAdminRole(input:{code:string;name:string;permissionCodes:string[]}){ return this.request<{id:string}>('/api/v1/admin/roles',{method:'POST',body:JSON.stringify(input)}); }
  getTenantSettings(){ return this.request<TenantSettings>('/api/v1/admin/settings'); }
  updateTenantSettings(input:Partial<{productName:string;organizationName:string|null;logoUrl:string|null;themeMode:'system'|'light'|'dark';accentColor:string;fontScale:number;uiScale:number;highContrast:boolean;reducedMotion:boolean;rankingEnabled:boolean;academicYear:string|null;academicTerm:string|null;footerText:string|null;developerName:string|null}>){ return this.request<TenantSettings>('/api/v1/admin/settings',{method:'PATCH',body:JSON.stringify(input)}); }
  restoreEncryptedBackup(password:string,contentBase64:string){ return this.request<{restoreId:string;checksum:string;rowCount:number;tableCount:number;status:'completed'}>('/api/v1/admin/backups/restore',{method:'POST',body:JSON.stringify({password,contentBase64,confirmation:'RESTORE'})}); }

  updateAdminRole(roleId:string,input:{name?:string;permissionCodes?:string[]}){ return this.request<{id:string}>(`/api/v1/admin/roles/${encodeURIComponent(roleId)}`,{method:'PATCH',body:JSON.stringify(input)}); }
  getTypedReport(type:'student'|'class'|'grade'|'subject'|'exam'|'subscription'|'teacher'|'performance'|'question_difficulty'|'effectiveness'|'error_analysis'){return this.request<{type:string;items:any[]}>(`/api/v1/admin/reports/${encodeURIComponent(type)}`);}
  exportTypedReport(type:'student'|'class'|'grade'|'subject'|'exam'|'subscription'|'teacher'|'performance'|'question_difficulty'|'effectiveness'|'error_analysis',format:'csv'|'excel_xml'|'word_html'){return this.request<{filename:string;mimeType:string;contentBase64:string;sizeBytes:number}>(`/api/v1/admin/reports/${encodeURIComponent(type)}/export?format=${encodeURIComponent(format)}`);}
  exportResultsReport(format:'csv'|'excel_xml'|'word_html'){ return this.request<{filename:string;mimeType:string;contentBase64:string;sizeBytes:number}>(`/api/v1/admin/reports/results/export?format=${encodeURIComponent(format)}`); }
  exportResultsPdf(){ return this.request<{filename:string;mimeType:string;contentBase64:string;sizeBytes:number}>('/api/v1/admin/reports/results/export.pdf'); }


  listAuditLogs(params:{page?:number;pageSize?:number;action?:string;actorType?:'user'|'student'|'system';entityType?:string;search?:string;from?:string;to?:string}={}){const q=new URLSearchParams();Object.entries(params).forEach(([k,v])=>{if(v!==undefined&&v!=='')q.set(k,String(v));});return this.request<Page<any>>(`/api/v1/admin/audit-logs${q.size?`?${q}`:''}`);}
  importStudentsBatch(rows:Array<{rowNo:number;fullName:string;seatNumber:string;legacyRef?:string|null;status?:'active'|'archived';grade?:string|null;classSection?:string|null;school?:string|null;governorate?:string|null;phone?:string|null;guardianPhone?:string|null;notes?:string|null}>){return this.request<{processed:number;inserted:number;updated:number;errorRows:number;errors:Array<{rowNo:number;message:string}>}>('/api/v1/admin/students/bulk-import',{method:'POST',body:JSON.stringify({rows})});}
  exportStudentsCsv(){return this.request<{filename:string;mimeType:string;contentBase64:string;sizeBytes:number}>('/api/v1/admin/students/export.csv');}
  exportStudentsExcel(){return this.request<{filename:string;mimeType:string;contentBase64:string;sizeBytes:number}>('/api/v1/admin/students/export.excel.xml');}
  listBackupSchedules(){return this.request<{items:any[]}>('/api/v1/admin/backup-schedules');}
  createBackupSchedule(input:{name:string;cronExpression:string;enabled?:boolean;destinationKind?:'external'|'local'|'s3_compatible';destinationConfig?:Record<string,unknown>;encryptionKeyRef?:string|null;nextRunAt?:string|null}){return this.request<{id:string}>('/api/v1/admin/backup-schedules',{method:'POST',body:JSON.stringify(input)});}
  setBackupScheduleEnabled(scheduleId:string,enabled:boolean){return this.request<void>(`/api/v1/admin/backup-schedules/${encodeURIComponent(scheduleId)}/enabled`,{method:'PATCH',body:JSON.stringify({enabled})});}

  updateStudent(studentId:string,input:Partial<{fullName:string;seatNumber:string;grade:string|null;classSection:string|null;school:string|null;governorate:string|null;phone:string|null;guardianPhone:string|null;notes:string|null;status:'active'|'archived'}>){return this.request<StudentRow>(`/api/v1/admin/students/${encodeURIComponent(studentId)}`,{method:'PATCH',body:JSON.stringify(input)});}
  restoreStudent(studentId:string){return this.request<StudentRow>(`/api/v1/admin/students/${encodeURIComponent(studentId)}/restore`,{method:'POST'});}
  printSelectedQuestions(questionIds:string[]){return this.request<{html:string}>('/api/v1/admin/questions/selection/print',{method:'POST',body:JSON.stringify({questionIds})});}
  shareSelectedQuestions(questionIds:string[]){return this.request<{filename:string;mimeType:string;contentBase64:string;sizeBytes:number;count:number}>('/api/v1/admin/questions/selection/share',{method:'POST',body:JSON.stringify({questionIds})});}
  getQuestionImportTemplate(format:'csv'|'xml'|'excel_xml'){return this.request<{filename:string;mimeType:string;contentBase64:string;sizeBytes:number}>(`/api/v1/admin/question-imports/template?format=${encodeURIComponent(format)}`);}
  previewQuestionsXlsx(file:ArrayBuffer|Blob,mapping:Record<string,string>={}){return this.request<{format:'xlsx';headers:string[];totalRows:number;rows:any[]}>('/api/v1/admin/question-imports/xlsx/preview',{method:'POST',headers:{'content-type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','x-column-mapping':encodeURIComponent(JSON.stringify(mapping))},body:file instanceof Blob?file:new Blob([file])});}
  previewQuestionsCsv(text:string,mapping:Record<string,string>={}){return this.request<{format:'csv';headers:string[];totalRows:number;rows:any[]}>('/api/v1/admin/question-imports/csv/preview',{method:'POST',headers:{'content-type':'text/csv','x-column-mapping':encodeURIComponent(JSON.stringify(mapping))},body:text});}
  previewQuestionsJson(data:unknown,mapping:Record<string,string>={}){return this.request<{format:'json';headers:string[];totalRows:number;rows:any[]}>('/api/v1/admin/question-imports/json/preview',{method:'POST',headers:{'x-column-mapping':encodeURIComponent(JSON.stringify(mapping))},body:JSON.stringify(data)});}
  uploadQuestionXlsx(file:Blob|ArrayBuffer,filename='questions.xlsx',mapping:Record<string,string>={},mode:'skip'|'upsert'='skip'){return this.request<{job:ImportJob;summary:{received:number;inserted:number;updated:number;duplicates:number;invalid:number;batches:number}}>('/api/v1/admin/question-imports/xlsx',{method:'POST',headers:{'content-type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','x-file-name':filename,'x-column-mapping':encodeURIComponent(JSON.stringify(mapping))},body:file instanceof Blob?file:new Blob([file])});}
  uploadQuestionCsv(text:string,filename='questions.csv',mapping:Record<string,string>={},mode:'skip'|'upsert'='skip'){return this.request<{job:ImportJob;summary:{received:number;inserted:number;updated:number;duplicates:number;invalid:number;batches:number}}>('/api/v1/admin/question-imports/csv',{method:'POST',headers:{'content-type':'text/csv','x-file-name':filename,'x-column-mapping':encodeURIComponent(JSON.stringify(mapping))},body:text});}
  uploadQuestionJson(data:unknown,filename='questions.json',mapping:Record<string,string>={},mode:'skip'|'upsert'='skip'){return this.request<{job:ImportJob;summary:{received:number;inserted:number;updated:number;duplicates:number;invalid:number;batches:number}}>('/api/v1/admin/question-imports/json',{method:'POST',headers:{'x-file-name':filename,'x-column-mapping':encodeURIComponent(JSON.stringify(mapping)),'x-import-mode':mode},body:JSON.stringify(data)});}
  listMigrationRuns(){return this.request<any[]>('/api/v1/admin/migrations/runs');}
  listQuestionRemediation(input:{runId?:string;status?:'pending'|'resolved'|'discarded';reasonCode?:string;page?:number;pageSize?:number}={}){const q=new URLSearchParams();for(const [k,v] of Object.entries(input))if(v!==undefined)q.set(k,String(v));return this.request<{items:any[];total:number;page:number;pageSize:number}>(`/api/v1/admin/migrations/remediation?${q.toString()}`);}
  resolveQuestionRemediation(id:string,input:{status:'resolved'|'discarded';resolutionNote:string;resolvedQuestionId?:string|null}){return this.request<any>(`/api/v1/admin/migrations/remediation/${encodeURIComponent(id)}/resolve`,{method:'POST',body:JSON.stringify(input)});}
  getMigrationMaterialization(runId?:string){const q=runId?`?runId=${encodeURIComponent(runId)}`:'';return this.request<{items:any[]}>(`/api/v1/admin/migrations/materialization${q}`);}
  materializeMigrationBatch(input:{runId:string;sourceSha256:string;entityKind:'taxonomy'|'questions'|'aliases'|'remediation'|'students';batchNo:number;rows:Record<string,unknown>[]}){return this.request<{replayed:boolean;entityKind:string;batchNo:number;rowCount:number;applied:number;skipped:number;payloadHash:string}>('/api/v1/admin/migrations/materialize-batch',{method:'POST',body:JSON.stringify(input)});}

}
